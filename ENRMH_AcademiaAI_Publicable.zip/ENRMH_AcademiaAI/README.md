# ENRMH AcademiaAI — MVP preparado para despliegue

Aplicación web en Python + Streamlit para apoyar procesos académicos de la Escuela Normal Rural “Miguel Hidalgo”. Incluye Planeación 2022, Evaluación, Titulación, Investigación, Tutoría y Consulta documental.

## Ejecución local

Requiere Python 3.11 o 3.12.

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

La aplicación se abrirá normalmente en `http://localhost:8501`.

La portada usa una imagen institucional incluida en `static/assets/` y servida localmente por Streamlit. Los botones mantienen sus etiquetas y acciones, con estados visibles de interacción, foco y deshabilitado; la animación respeta la preferencia del sistema por movimiento reducido.

## Publicación web con Streamlit Community Cloud

1. Descomprime esta carpeta y sube su contenido a un repositorio GitHub propio.
2. Entra a https://share.streamlit.io/ e inicia sesión con GitHub.
3. Crea una aplicación y selecciona el repositorio, la rama y `app.py` como archivo principal.
4. Despliega. El modo **Modo demostración** funciona sin clave de IA y permite comprobar la interfaz y la recuperación documental.
5. Para generar respuestas con un modelo remoto, abre **App settings → Secrets** y configura, por ejemplo:

```toml
OPENAI_API_KEY = "tu_clave_de_api"
OPENAI_MODEL = "gpt-4o-mini"
OPENAI_BASE_URL = "https://api.openai.com/v1"
```

La clave debe configurarse como secreto del alojamiento; nunca la publiques en GitHub ni la escribas directamente en `app.py`. El uso de una API puede generar costos según el proveedor.

## Documentos institucionales

Coloca documentos autorizados en `docs/` en formato `.md` o `.txt`. El prototipo no extrae texto directamente de PDF/Word y el índice se reconstruye al consultar. El archivo `documento_demo_enrmh.md` es demostrativo, no normativa institucional.

## Alcance y límites de esta versión

- El RAG usa coincidencia léxica ligera, no embeddings ni una base vectorial persistente.
- Los indicadores son propuestas de ejemplo, no datos institucionales verificados.
- El despliegue público hace que la interfaz sea accesible por internet; no equivale a control de acceso institucional.
- Antes de cargar expedientes, datos personales, documentos de titulación o información confidencial, se deben implementar autenticación, roles, autorización, auditoría y reglas de privacidad.
- No se deben subir documentos sensibles a un proveedor de IA externo sin autorización institucional.
- La IA apoya, pero no sustituye, las decisiones académicas del personal responsable.
