import os, re, json, math, glob, requests
from pathlib import Path
from typing import List, Dict

APP_TITLE = "ENRMH AcademiaAI"
BASE = Path(__file__).parent
DOCS = BASE / "docs"
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2:3b")
LMSTUDIO_URL = os.getenv("LMSTUDIO_URL", "http://localhost:1234/v1")
API_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
API_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
API_KEY = os.getenv("OPENAI_API_KEY", "")

try:
    import streamlit as st
except ImportError:
    st = None

# ---------------- RAG ligero y local ----------------
def tokenize(s):
    return set(re.findall(r"[a-záéíóúüñ0-9]+", s.lower()))

def read_text_file(path):
    try:
        return path.read_text(encoding='utf-8')
    except Exception:
        return ''

def load_documents():
    docs=[]
    for p in sorted(DOCS.rglob('*')):
        if p.is_file() and p.suffix.lower() in {'.txt','.md'}:
            txt=read_text_file(p)
            if txt.strip(): docs.append({'source':p.name,'text':txt})
    return docs

def chunks(text, size=900, overlap=120):
    words=text.split()
    out=[]
    i=0
    while i<len(words):
        out.append(' '.join(words[i:i+size]))
        i += max(1,size-overlap)
    return out

def retrieve(query, docs, k=5):
    q=tokenize(query)
    scored=[]
    for d in docs:
        for c in chunks(d['text']):
            t=tokenize(c)
            score=len(q&t)/(math.sqrt(len(q))*math.sqrt(len(t)) or 1)
            if score>0: scored.append((score,d['source'],c))
    scored.sort(reverse=True)
    return scored[:k]

def ollama(prompt):
    r=requests.post(f'{OLLAMA_URL}/api/generate',json={'model':OLLAMA_MODEL,'prompt':prompt,'stream':False},timeout=90)
    r.raise_for_status(); return r.json().get('response','')

def lmstudio(prompt):
    r=requests.post(f'{LMSTUDIO_URL}/chat/completions',json={'model':'local-model','messages':[{'role':'user','content':prompt}],'temperature':0.2},timeout=90)
    r.raise_for_status(); return r.json()['choices'][0]['message']['content']

def compatible_api(prompt):
    if not API_KEY:
        raise RuntimeError('Falta configurar OPENAI_API_KEY en los secretos de la plataforma de despliegue.')
    r = requests.post(
        f'{API_BASE_URL}/chat/completions',
        headers={'Authorization': f'Bearer {API_KEY}', 'Content-Type': 'application/json'},
        json={'model': API_MODEL, 'messages': [{'role': 'user', 'content': prompt}], 'temperature': 0.2},
        timeout=90,
    )
    r.raise_for_status()
    return r.json()['choices'][0]['message']['content']

def generate(prompt, provider):
    if provider == 'Ollama': return ollama(prompt)
    if provider == 'LM Studio': return lmstudio(prompt)
    if provider == 'API compatible (nube)': return compatible_api(prompt)
    return ''

def grounded_prompt(question, contexts, module):
    sources='\n\n'.join([f'[FUENTE: {s}]\n{c}' for _,s,c in contexts])
    return f'''Eres ENRMH AcademiaAI, asistente académico de la Escuela Normal Rural “Miguel Hidalgo”.\nMódulo: {module}.\n\nREGLAS:\n1) Responde en español claro, profesional y orientado al Plan de Estudios 2022 de educación normal y a la Nueva Escuela Mexicana.\n2) Usa primero la información recuperada. No inventes reglamentos, artículos, porcentajes, nombres o fechas.\n3) Si las fuentes no permiten responder, dilo explícitamente y señala qué documento hace falta.\n4) Diferencia hechos documentados de sugerencias pedagógicas.\n5) Termina con “Fuentes consultadas” y enumera los nombres de archivo utilizados.\n\nDOCUMENTOS RECUPERADOS:\n{sources or 'No se recuperaron documentos pertinentes.'}\n\nPREGUNTA/TAREA:\n{question}'''

def demo_answer(question,module,contexts):
    if contexts:
        src='; '.join(dict.fromkeys(s for _,s,_ in contexts))
        return (f"Modo demostración local. Para la solicitud del módulo {module}, el sistema recuperó información de: {src}.\n\n"
                "La respuesta generativa se activará al conectar Ollama o LM Studio. En producción, el modelo deberá fundamentar la respuesta exclusivamente en los documentos recuperados y declarar las fuentes.")
    return 'No hay documentos de conocimiento suficientes. Agrega documentos institucionales en la carpeta docs y vuelve a indexar.'

def run_cli():
    docs=load_documents(); q='¿Cómo puede fortalecerse el acompañamiento académico con el Plan 2022?'
    ctx=retrieve(q,docs)
    print('ENRMH AcademiaAI — prueba local')
    print('Documentos:',len(docs),'Fragmentos recuperados:',len(ctx))
    print(demo_answer(q,'Consulta documental',ctx))

if st:
    st.set_page_config(page_title=APP_TITLE,page_icon='🎓',layout='wide')
    st.title('🎓 ENRMH AcademiaAI')
    st.caption('Asistente local para acompañamiento y fortalecimiento académico · Plan de Estudios 2022 · Nueva Escuela Mexicana')
    with st.sidebar:
        st.header('Configuración')
        provider=st.selectbox('Motor de IA', ['Modo demostración','API compatible (nube)','Ollama','LM Studio'], index=0)
        st.caption('En despliegue público, selecciona API compatible y configura la clave como secreto. Ollama/LM Studio solo funcionan si el servidor puede acceder a ellos.')
        module=st.selectbox('Agente especializado',['Planeación 2022','Evaluación','Titulación','Investigación','Tutoría','Consulta documental'])
        st.divider(); st.write(f'Documentos locales: **{len(load_documents())}**')
        st.info('Los documentos de /docs permanecen en este equipo. La privacidad real depende de la configuración de la infraestructura local.')
    tabs=st.tabs(['💬 Asistente','📚 Base documental','📊 Seguimiento','🧭 Arquitectura'])
    with tabs[0]:
        st.subheader(module)
        q=st.text_area('¿Qué necesitas resolver?',height=130,placeholder='Ej.: Diseña una estrategia de acompañamiento para una unidad de aprendizaje del Plan 2022...')
        if st.button('Consultar / Generar',type='primary') and q.strip():
            docs=load_documents(); ctx=retrieve(q,docs)
            if provider=='Modo demostración': ans=demo_answer(q,module,ctx)
            else:
                try: ans=generate(grounded_prompt(q,ctx,module),provider)
                except Exception as e:
                    detail = str(e)
                    if 'Falta configurar OPENAI_API_KEY' in detail:
                        ans = 'Falta configurar OPENAI_API_KEY en los secretos del servicio de alojamiento. Puedes usar Modo demostración mientras tanto.'
                    else:
                        ans = f'No fue posible conectar con {provider}. Verifica la configuración del motor de IA.\n\nDetalle: {detail[:400]}\n\nFragmentos recuperados: {len(ctx)}'
            st.markdown(ans)
            if ctx:
                with st.expander('Ver evidencia recuperada (RAG)'):
                    for score,src,c in ctx: st.markdown(f'**{src} · relevancia {score:.2f}**\n\n{c[:1400]}')
    with tabs[1]:
        st.subheader('Base de conocimiento institucional')
        docs=load_documents()
        if docs:
            for d in docs: st.success(d['source'])
        else: st.warning('No hay documentos. Coloca .txt o .md en /docs.')
    with tabs[2]:
        st.subheader('Indicadores de acompañamiento')
        st.markdown('| Indicador | Meta inicial | Evidencia |\n|---|---:|---|\n| Planeaciones asistidas | 10/mes | Planeación revisada |\n| Consultas documentales fundamentadas | 20/mes | Respuesta + fuentes |\n| Instrumentos de evaluación generados | 8/mes | Rúbrica/lista/reactivos |\n| Procesos de titulación acompañados | 10/mes | Registro de avance |\n| Tiempo ahorrado | Medir línea base | Comparativo |')
        st.info('Estas metas son propuestas del prototipo, no datos institucionales.')
    with tabs[3]:
        st.subheader('Arquitectura')
        st.code('''Documentos ENRMH → Procesamiento → Fragmentación → Recuperación semántica (RAG)\n                                      ↓\n                     LLM local (Ollama / LM Studio)\n                                      ↓\n              Agentes: Planeación · Evaluación · Titulación\n                      Investigación · Tutoría · RAG\n                                      ↓\n                     Interfaz ENRMH AcademiaAI''')
        st.write('Principio: la IA asiste; la decisión académica permanece en el personal responsable.')
else:
    if __name__=='__main__': run_cli()
