import os, re, json, math, glob, requests
from pathlib import Path
from typing import List, Dict

APP_TITLE = "ENRMH AcademiaAI"
BASE = Path(__file__).parent
DOCS = BASE / "docs"
MODULES = [
    'Planeación 2022',
    'Evaluación',
    'Titulación',
    'Investigación',
    'Tutoría',
    'Consulta documental',
]
AREA_DIRECTORIES = {
    'planeacion': ('Planeación 2022', 'Programas, secuencias didácticas y planeaciones.'),
    'evaluacion': ('Evaluación', 'Rúbricas, listas de cotejo e instrumentos de evaluación.'),
    'titulacion': ('Titulación', 'Orientaciones y seguimiento de procesos de titulación.'),
    'investigacion': ('Investigación', 'Protocolos, metodologías y recursos de investigación.'),
    'tutoria': ('Tutoría', 'Materiales para diagnóstico y acompañamiento tutorial.'),
    'transversal': ('Documentos transversales', 'Referentes institucionales compartidos entre áreas.'),
}
MAX_DOCUMENT_SIZE = 10 * 1024 * 1024
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2:3b")
LMSTUDIO_URL = os.getenv("LMSTUDIO_URL", "http://localhost:1234/v1")
API_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
API_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
API_KEY = os.getenv("OPENAI_API_KEY", "")

try:
    import streamlit as st
except ImportError:
    st = None

# ---------------- RAG ligero y local ----------------
def tokenize(s):
    return set(re.findall(r"[a-záéíóúüñ0-9]+", s.lower()))

def read_text_file(path):
    return path.read_text(encoding='utf-8')

def load_documents():
    docs=[]
    for p in sorted(DOCS.rglob('*')):
        if p.is_file() and p.name.lower() not in {'readme.md', 'leeme.md'} and p.suffix.lower() in {'.txt','.md'}:
            txt=read_text_file(p)
            if txt.strip():
                relative_path = p.relative_to(DOCS)
                area = AREA_DIRECTORIES.get(relative_path.parts[0], ('General', 'Documentos institucionales generales.'))[0] if len(relative_path.parts) > 1 else 'General'
                docs.append({'source':relative_path.as_posix(),'area':area,'text':txt})
    return docs

def save_uploaded_documents(uploaded_files, area_directory):
    if area_directory not in AREA_DIRECTORIES:
        raise ValueError('Selecciona un área institucional válida.')

    area_path = DOCS / area_directory
    area_path.mkdir(parents=True, exist_ok=True)
    saved = []
    errors = []
    for uploaded_file in uploaded_files:
        filename = uploaded_file.name.replace('\\', '/').rsplit('/', 1)[-1]
        suffix = Path(filename).suffix.lower()
        if not filename or filename in {'.', '..'} or filename.lower() in {'readme.md', 'leeme.md'} or suffix not in {'.md', '.txt'}:
            errors.append(f'{uploaded_file.name}: usa un nombre de archivo válido con extensión .md o .txt.')
            continue
        stem = filename.split('.', 1)[0].upper()
        invalid_name = (
            len(filename) > 240
            or any(ord(character) < 32 or character in '<>:"|?*' for character in filename)
            or filename.endswith((' ', '.'))
            or stem in {'CON', 'PRN', 'AUX', 'NUL'}
            or re.fullmatch(r'(COM|LPT)[1-9]', stem) is not None
        )
        if invalid_name:
            errors.append(f'{filename}: el nombre no es válido en este sistema.')
            continue

        content = uploaded_file.getvalue()
        if not content:
            errors.append(f'{filename}: el archivo está vacío.')
            continue
        if len(content) > MAX_DOCUMENT_SIZE:
            errors.append(f'{filename}: supera el límite de 10 MB.')
            continue
        try:
            content.decode('utf-8')
        except UnicodeDecodeError:
            errors.append(f'{filename}: guarda el documento como texto UTF-8.')
            continue

        destination = area_path / filename
        if destination.exists():
            errors.append(f'{filename}: ya existe en el área seleccionada; no se sobrescribió.')
            continue
        destination.write_bytes(content)
        saved.append(f'{area_directory}/{filename}')
    return saved, errors

if st:
    load_documents = st.cache_data(show_spinner=False)(load_documents)

MODULE_TEMPLATES = {
    'Planeación 2022': {
        'Diseño de secuencia didáctica': 'Diseña una secuencia didáctica para [curso o unidad] del Plan de Estudios 2022. Contexto del grupo: [semestre, características y contexto escolar]. Propósito formativo: [propósito]. Incluye actividades de inicio, desarrollo y cierre, evidencias, recursos y criterios de seguimiento. Distingue las sugerencias de la información respaldada por documentos institucionales.',
        'Articulación curricular': 'Ayúdame a articular [contenido o problema del contexto] con el perfil de egreso y los propósitos de [curso o unidad] del Plan 2022. Propón una ruta de trabajo, evidencias y preguntas para reflexión docente; señala qué aspectos requieren validación con el programa oficial.',
        'Proyecto situado': 'Propón un proyecto situado sobre [necesidad del contexto escolar o comunitario] para [grupo o semestre]. Describe propósito, fases, colaboración con la comunidad, productos y formas de valorar el proceso, sin inventar datos institucionales.',
    },
    'Evaluación': {
        'Rúbrica analítica': 'Elabora una rúbrica analítica para valorar [evidencia o desempeño] en [curso o unidad]. Propósito: [propósito de aprendizaje]. Incluye criterios observables y cuatro niveles descriptivos; alinea la propuesta con los documentos recuperados y marca los elementos que el docente debe ajustar.',
        'Lista de cotejo': 'Diseña una lista de cotejo para revisar [producto o desempeño] de [grupo o semestre]. Incluye indicadores verificables, espacio para observaciones y una breve guía de retroalimentación formativa. No asumas ponderaciones que no estén documentadas.',
        'Retroalimentación formativa': 'Ayúdame a redactar retroalimentación descriptiva para [evidencia], considerando estos logros: [logros] y próximos pasos: [necesidades]. Mantén un tono respetuoso, específico y orientado a la mejora; no atribuyas resultados no proporcionados.',
    },
    'Titulación': {
        'Plan de seguimiento': 'Prepara un plan de seguimiento para el proceso de titulación de [estudiante o grupo, sin datos personales]. Etapa actual: [etapa]; avance: [avance]; próximo hito: [hito]. Organiza acuerdos, evidencias por reunir y preguntas de acompañamiento, sujeto a la normativa institucional vigente.',
        'Delimitación del tema': 'Ayúdame a delimitar un tema de titulación sobre [tema o práctica educativa] en [contexto]. Sugiere problema, pregunta orientadora y objetivos preliminares; diferencia las propuestas de cualquier requisito normativo que deba verificarse.',
        'Agenda de asesoría': 'Propón una agenda para una asesoría de titulación de [duración] sobre [necesidad del proceso]. Incluye revisión de avances, preguntas para el diálogo, acuerdos y evidencias para la siguiente sesión.',
    },
    'Investigación': {
        'Pregunta de investigación': 'Ayúdame a convertir esta situación educativa en preguntas investigables: [situación y contexto]. Propón una pregunta principal, subpreguntas y objetivos preliminares; indica supuestos que todavía debo comprobar y evita presentar hipótesis como hechos.',
        'Diseño metodológico': 'Compara alternativas metodológicas para estudiar [fenómeno educativo] en [contexto y participantes]. Considera propósito, tipo de evidencias y resguardos éticos. Presenta opciones razonadas y señala qué decisión corresponde al equipo investigador.',
        'Instrumentos de indagación': 'Propón un borrador de [guía de entrevista, observación o cuestionario] para explorar [tema] con [participantes]. Usa preguntas claras y no sugestivas, incluye propósito y consideraciones de consentimiento; el instrumento deberá revisarse antes de aplicarse.',
    },
    'Tutoría': {
        'Plan de acompañamiento': 'Diseña un plan inicial de acompañamiento tutorial para [grupo o semestre], a partir de estas necesidades observadas: [necesidades]. Organiza objetivos, acciones, frecuencia y señales de seguimiento sin diagnosticar ni etiquetar a estudiantes.',
        'Sesión tutorial': 'Prepara una sesión tutorial de [duración] sobre [tema o necesidad]. Incluye propósito, apertura, actividad participativa, cierre y una forma voluntaria de recoger necesidades del grupo, cuidando la confidencialidad.',
        'Seguimiento de acuerdos': 'Ayúdame a organizar el seguimiento de estos acuerdos tutoriales: [acuerdos sin datos personales]. Resume responsables por rol, próximos pasos y fecha de revisión, y distingue lo confirmado de lo pendiente.',
    },
    'Consulta documental': {
        'Síntesis de fuentes': 'Sintetiza los documentos recuperados sobre [tema]. Organiza los puntos coincidentes, diferencias y límites de la evidencia; cita los nombres de los archivos y señala qué información no está disponible.',
        'Comparación de documentos': 'Compara las fuentes recuperadas sobre [tema o proceso]. Presenta una tabla con fuente, orientación principal y aspectos que requieren aclaración. No infieras vigencia normativa si el documento no la establece.',
        'Búsqueda de vacíos': 'A partir de los documentos recuperados sobre [tema], identifica preguntas que sí pueden responderse y vacíos documentales. Indica qué tipo de documento institucional haría falta para responder con fundamento.',
    },
}

def reset_template_for_module():
    st.session_state['template_choice'] = 'Solicitud libre'

def apply_selected_template():
    selected = st.session_state['template_choice']
    if selected != 'Solicitud libre':
        module = st.session_state['module_select']
        st.session_state['question'] = MODULE_TEMPLATES[module][selected]

def chunks(text, size=900, overlap=120):
    words=text.split()
    out=[]
    i=0
    while i<len(words):
        out.append(' '.join(words[i:i+size]))
        i += max(1,size-overlap)
    return out

def retrieve(query, docs, k=5):
    q=tokenize(query)
    scored=[]
    for d in docs:
        for c in chunks(d['text']):
            t=tokenize(c)
            score=len(q&t)/(math.sqrt(len(q))*math.sqrt(len(t)) or 1)
            if score>0: scored.append((score,d['source'],c))
    scored.sort(reverse=True)
    return scored[:k]

def build_answer_export(question, module, answer, contexts):
    lines = [
        '# ENRMH AcademiaAI',
        '',
        f'**Módulo:** {module}',
        f'**Consulta:** {question}',
        '',
        '## Respuesta',
        '',
        answer,
        '',
        '## Fuentes y citas',
        '',
    ]
    if contexts:
        citation_numbers = ', '.join(f'[{index}]' for index in range(1, len(contexts) + 1))
        lines.extend([
            f'Fragmentos de contexto recuperados para esta consulta: {citation_numbers}.',
            'Las referencias identifican archivos y extractos; no representan páginas ni una verificación automática de cada afirmación.',
            '',
        ])
        for index, (score, source, excerpt) in enumerate(contexts, start=1):
            quote = excerpt[:900].strip()
            if len(excerpt) > 900:
                quote += '…'
            lines.extend([
                f'[{index}] `docs/{source}` (relevancia de recuperación: {score:.2f})',
                '',
                '_Fragmento recuperado; el índice no conserva números de página._',
                '',
                *[f'> {line}' if line else '>' for line in quote.splitlines()],
                '',
            ])
    else:
        lines.append('No se recuperaron fragmentos documentales para esta consulta.')
    return '\n'.join(lines).rstrip() + '\n'

def ollama(prompt):
    r=requests.post(f'{OLLAMA_URL}/api/generate',json={'model':OLLAMA_MODEL,'prompt':prompt,'stream':False},timeout=90)
    r.raise_for_status(); return r.json().get('response','')

def lmstudio(prompt):
    r=requests.post(f'{LMSTUDIO_URL}/chat/completions',json={'model':'local-model','messages':[{'role':'user','content':prompt}],'temperature':0.2},timeout=90)
    r.raise_for_status(); return r.json()['choices'][0]['message']['content']

def compatible_api(prompt):
    if not API_KEY:
        raise RuntimeError('Falta configurar OPENAI_API_KEY en los secretos de la plataforma de despliegue.')
    r = requests.post(
        f'{API_BASE_URL}/chat/completions',
        headers={'Authorization': f'Bearer {API_KEY}', 'Content-Type': 'application/json'},
        json={'model': API_MODEL, 'messages': [{'role': 'user', 'content': prompt}], 'temperature': 0.2},
        timeout=90,
    )
    r.raise_for_status()
    return r.json()['choices'][0]['message']['content']

def generate(prompt, provider):
    if provider == 'Ollama': return ollama(prompt)
    if provider == 'LM Studio': return lmstudio(prompt)
    if provider == 'API compatible (nube)': return compatible_api(prompt)
    return ''

def grounded_prompt(question, contexts, module):
    sources='\n\n'.join([f'[FUENTE: {s}]\n{c}' for _,s,c in contexts])
    return f'''Eres ENRMH AcademiaAI, asistente académico de la Escuela Normal Rural “Miguel Hidalgo”.\nMódulo: {module}.\n\nREGLAS:\n1) Responde en español claro, profesional y orientado al Plan de Estudios 2022 de educación normal y a la Nueva Escuela Mexicana.\n2) Usa primero la información recuperada. No inventes reglamentos, artículos, porcentajes, nombres o fechas.\n3) Si las fuentes no permiten responder, dilo explícitamente y señala qué documento hace falta.\n4) Diferencia hechos documentados de sugerencias pedagógicas.\n5) Termina con “Fuentes consultadas” y enumera los nombres de archivo utilizados.\n\nDOCUMENTOS RECUPERADOS:\n{sources or 'No se recuperaron documentos pertinentes.'}\n\nPREGUNTA/TAREA:\n{question}'''

def demo_answer(question,module,contexts):
    if contexts:
        src='; '.join(dict.fromkeys(s for _,s,_ in contexts))
        return (f"Modo demostración local. Para la solicitud del módulo {module}, el sistema recuperó información de: {src}.\n\n"
                "La respuesta generativa se activará al conectar Ollama o LM Studio. En producción, el modelo deberá fundamentar la respuesta exclusivamente en los documentos recuperados y declarar las fuentes.")
    return 'No hay documentos de conocimiento suficientes. Agrega documentos institucionales en la carpeta docs y vuelve a indexar.'

def run_cli():
    docs=load_documents(); q='¿Cómo puede fortalecerse el acompañamiento académico con el Plan 2022?'
    ctx=retrieve(q,docs)
    print('ENRMH AcademiaAI — prueba local')
    print('Documentos:',len(docs),'Fragmentos recuperados:',len(ctx))
    print(demo_answer(q,'Consulta documental',ctx))

if st:
    st.set_page_config(page_title=APP_TITLE,page_icon='🎓',layout='wide')
    st.markdown("""
    <style>
    .institutional-hero {
        position: relative;
        isolation: isolate;
        display: flex;
        align-items: center;
        min-height: 260px;
        margin: 0 0 1.75rem;
        padding: clamp(1.5rem, 5vw, 3.5rem);
        overflow: hidden;
        border: 1px solid rgba(255, 255, 255, 0.18);
        border-radius: 1.25rem;
        color: #fff;
        background:
            linear-gradient(90deg, rgba(13, 36, 30, 0.94) 0%, rgba(13, 36, 30, 0.76) 48%, rgba(13, 36, 30, 0.16) 100%),
            url("/app/static/assets/enrmh-hero.jpg") center 43% / cover;
        box-shadow: 0 1rem 2.5rem rgba(19, 49, 40, 0.18);
    }
    .institutional-hero__content {
        max-width: 46rem;
        text-shadow: 0 2px 12px rgba(0, 0, 0, 0.45);
    }
    .institutional-hero__eyebrow {
        margin: 0 0 0.55rem;
        color: #f6d47c;
        font-size: 0.82rem;
        font-weight: 700;
        letter-spacing: 0.12em;
        text-transform: uppercase;
    }
    .institutional-hero h1 {
        margin: 0;
        color: #fff;
        font-size: clamp(2rem, 4vw, 3.25rem);
        line-height: 1.1;
    }
    .institutional-hero__description {
        max-width: 42rem;
        margin: 0.9rem 0 0;
        color: #fff;
        font-size: clamp(1rem, 1.6vw, 1.15rem);
        line-height: 1.6;
    }
    .stButton > button {
        min-height: 2.8rem;
        border: 1px solid #17624b;
        border-radius: 0.7rem;
        color: #fff;
        background: #17624b;
        font-weight: 650;
        transition: transform 160ms ease, box-shadow 160ms ease, background-color 160ms ease, border-color 160ms ease;
    }
    .stButton > button[kind="primary"] {
        border-color: #14563f;
        color: #fff;
        background: #17624b;
        box-shadow: 0 4px 12px rgba(23, 98, 75, 0.22);
    }
    .stButton > button[kind="secondary"] {
        border-color: #9bb9aa;
        color: #164f3e;
        background: #f7faf8;
    }
    .stButton > button:not(:disabled):hover {
        transform: translateY(-2px);
        border-color: #0d4635;
        color: #fff;
        background: #0d5a42;
        box-shadow: 0 8px 18px rgba(18, 71, 55, 0.24);
    }
    .stButton > button:not(:disabled):active {
        transform: translateY(0) scale(0.99);
        box-shadow: 0 2px 6px rgba(18, 71, 55, 0.2);
    }
    .stButton > button:focus-visible {
        outline: 3px solid #d29b2b;
        outline-offset: 3px;
        box-shadow: 0 0 0 5px rgba(255, 255, 255, 0.85);
    }
    .stButton > button:disabled {
        border-color: #c5d0ca;
        color: #68766f;
        background: #e8eeea;
        cursor: not-allowed;
        box-shadow: none;
    }
    @media (prefers-reduced-motion: reduce) {
        .stButton > button {
            transition: none;
        }
        .stButton > button:not(:disabled):hover,
        .stButton > button:not(:disabled):active {
            transform: none;
        }
    }
    </style>
    <section class="institutional-hero" role="banner" aria-labelledby="institutional-hero-title">
      <div class="institutional-hero__content">
        <p class="institutional-hero__eyebrow">Escuela Normal Rural Miguel Hidalgo</p>
        <h1 id="institutional-hero-title">🎓 ENRMH AcademiaAI</h1>
        <p class="institutional-hero__description">Asistente local para acompañamiento y fortalecimiento académico · Plan de Estudios 2022 · Nueva Escuela Mexicana</p>
      </div>
    </section>
    """, unsafe_allow_html=True)
    with st.sidebar:
        st.header('Configuración')
        provider=st.selectbox('Motor de IA', ['Modo demostración','API compatible (nube)','Ollama','LM Studio'], index=0)
        st.caption('En despliegue público, selecciona API compatible y configura la clave como secreto. Ollama/LM Studio solo funcionan si el servidor puede acceder a ellos.')
        module=st.selectbox('Agente especializado',MODULES,key='module_select',on_change=reset_template_for_module)
        st.divider(); st.write(f'Documentos locales: **{len(load_documents())}**')
        st.info('Los documentos de /docs permanecen en este equipo. La privacidad real depende de la configuración de la infraestructura local.')
    tabs=st.tabs(['💬 Asistente','📚 Base documental','📊 Seguimiento','🧭 Arquitectura'])
    with tabs[0]:
        st.subheader(module)
        template_options = ['Solicitud libre', *MODULE_TEMPLATES[module].keys()]
        if st.session_state.get('template_choice') not in template_options:
            st.session_state['template_choice'] = 'Solicitud libre'
        st.selectbox('Plantilla para iniciar',template_options,key='template_choice',on_change=apply_selected_template)
        st.caption('Elige una guía y adapta los campos entre corchetes antes de consultar.')
        q=st.text_area('¿Qué necesitas resolver?',height=180,placeholder='Ej.: Diseña una estrategia de acompañamiento para una unidad de aprendizaje del Plan 2022...',key='question')
        if st.button('Consultar / Generar',type='primary') and q.strip():
            docs=load_documents(); ctx=retrieve(q,docs)
            if provider=='Modo demostración': ans=demo_answer(q,module,ctx)
            else:
                try: ans=generate(grounded_prompt(q,ctx,module),provider)
                except Exception as e:
                    detail = str(e)
                    if 'Falta configurar OPENAI_API_KEY' in detail:
                        ans = 'Falta configurar OPENAI_API_KEY en los secretos del servicio de alojamiento. Puedes usar Modo demostración mientras tanto.'
                    else:
                        ans = f'No fue posible conectar con {provider}. Verifica la configuración del motor de IA.\n\nDetalle: {detail[:400]}\n\nFragmentos recuperados: {len(ctx)}'
            st.session_state['last_answer'] = ans
            st.session_state['last_question'] = q
            st.session_state['last_module'] = module
            st.session_state['last_contexts'] = ctx
        if st.session_state.get('last_answer'):
            st.markdown(st.session_state['last_answer'])
            answer_export = build_answer_export(
                st.session_state['last_question'],
                st.session_state['last_module'],
                st.session_state['last_answer'],
                st.session_state['last_contexts'],
            )
            st.download_button(
                'Descargar respuesta con fuentes y citas',
                data=answer_export,
                file_name='respuesta_enrmh_academiaai.md',
                mime='text/markdown',
            )
            if st.session_state['last_contexts']:
                with st.expander('Ver evidencia recuperada (RAG)'):
                    for index, (score,src,c) in enumerate(st.session_state['last_contexts'], start=1):
                        st.markdown(f'**[{index}] {src} · relevancia {score:.2f}**\n\n{c[:1400]}')
    with tabs[1]:
        st.subheader('Base de conocimiento institucional')
        if st.button('Reindexar documentos',type='primary',help='Vuelve a leer los documentos .md y .txt de todas las áreas institucionales.'):
            load_documents.clear()
            st.session_state['reindex_notice'] = 'Índice actualizado con los documentos institucionales disponibles.'
            st.rerun()
        if st.session_state.pop('reindex_notice',None):
            st.success('Índice actualizado con los documentos institucionales disponibles.')
        docs=load_documents()
        st.caption(f'{len(docs)} documentos indexados. Después de agregar o actualizar archivos, selecciona “Reindexar documentos”.')
        st.markdown('**Directorio institucional**')
        for area_dir, (area_name, description) in AREA_DIRECTORIES.items():
            st.markdown(f'- **`docs/{area_dir}/` · {area_name}:** {description}')
        st.markdown('**Agregar documentos**')
        upload_area = st.selectbox(
            'Área de destino',
            list(AREA_DIRECTORIES),
            format_func=lambda key: AREA_DIRECTORIES[key][0],
            key='upload_area',
        )
        uploader_key = f'document_uploads_{st.session_state.get("upload_widget_version", 0)}'
        uploaded_files = st.file_uploader(
            'Arrastra aquí o selecciona archivos .md o .txt (UTF-8, máximo 10 MB por archivo).',
            type=['md', 'txt'],
            accept_multiple_files=True,
            key=uploader_key,
        )
        if st.button('Guardar documentos', disabled=not uploaded_files):
            saved, errors = save_uploaded_documents(uploaded_files, upload_area)
            st.session_state['document_upload_notice'] = (saved, errors)
            if saved:
                load_documents.clear()
                st.session_state['upload_widget_version'] = st.session_state.get('upload_widget_version', 0) + 1
            st.rerun()
        upload_notice = st.session_state.pop('document_upload_notice', None)
        if upload_notice:
            saved, errors = upload_notice
            if saved:
                st.success(f'Se guardaron y reindexaron {len(saved)} documento(s): {", ".join(saved)}')
            for error in errors:
                st.error(error)

        st.markdown('**Explorar documentos**')
        area_filter, type_filter = st.columns(2)
        areas = ['Todas las áreas', *dict.fromkeys(document['area'] for document in docs)]
        with area_filter:
            selected_area = st.selectbox('Filtrar por área', areas, key='document_area_filter')
        with type_filter:
            selected_type = st.selectbox('Filtrar por tipo', ['Todos los tipos', '.md', '.txt'], key='document_type_filter')
        filtered_docs = [
            document for document in docs
            if (selected_area == 'Todas las áreas' or document['area'] == selected_area)
            and (selected_type == 'Todos los tipos' or Path(document['source']).suffix.lower() == selected_type)
        ]
        st.caption(f'{len(filtered_docs)} de {len(docs)} documentos coinciden con los filtros.')
        if filtered_docs:
            document_labels = {
                document['source']: f'{document["source"]} · {document["area"]}'
                for document in filtered_docs
            }
            selected_source = st.selectbox(
                'Vista previa del documento',
                [document['source'] for document in filtered_docs],
                format_func=lambda source: document_labels[source],
                key='preview_document',
            )
            preview_doc = next(document for document in filtered_docs if document['source'] == selected_source)
            preview_content = preview_doc['text']
            if len(preview_content) > 12000:
                preview_content = preview_content[:12000] + '\n\n[Vista previa truncada a 12,000 caracteres.]'
            st.caption(f'Área: {preview_doc["area"]} · Tipo: {Path(selected_source).suffix.lower()}')
            st.code(preview_content, language='markdown' if Path(selected_source).suffix.lower() == '.md' else 'text')
        else:
            st.info('No hay documentos que coincidan. Ajusta los filtros o agrega documentos en el área correspondiente.')
    with tabs[2]:
        st.subheader('Indicadores de acompañamiento')
        st.markdown('| Indicador | Meta inicial | Evidencia |\n|---|---:|---|\n| Planeaciones asistidas | 10/mes | Planeación revisada |\n| Consultas documentales fundamentadas | 20/mes | Respuesta + fuentes |\n| Instrumentos de evaluación generados | 8/mes | Rúbrica/lista/reactivos |\n| Procesos de titulación acompañados | 10/mes | Registro de avance |\n| Tiempo ahorrado | Medir línea base | Comparativo |')
        st.info('Estas metas son propuestas del prototipo, no datos institucionales.')
    with tabs[3]:
        st.subheader('Arquitectura')
        st.code('''Documentos ENRMH → Procesamiento → Fragmentación → Recuperación semántica (RAG)\n                                      ↓\n                     LLM local (Ollama / LM Studio)\n                                      ↓\n              Agentes: Planeación · Evaluación · Titulación\n                      Investigación · Tutoría · RAG\n                                      ↓\n                     Interfaz ENRMH AcademiaAI''')
        st.write('Principio: la IA asiste; la decisión académica permanece en el personal responsable.')
else:
    if __name__=='__main__': run_cli()
