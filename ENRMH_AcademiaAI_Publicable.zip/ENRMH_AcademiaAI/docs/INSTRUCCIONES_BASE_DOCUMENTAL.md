# Base documental ENRMH

Coloque aquí únicamente documentos institucionales autorizados para consulta del sistema.

## Directorio por área

- `planeacion/`: planeaciones, programas y secuencias.
- `evaluacion/`: instrumentos, rúbricas y orientaciones de evaluación.
- `titulacion/`: materiales autorizados para acompañar procesos de titulación.
- `investigacion/`: protocolos, metodologías y recursos de investigación.
- `tutoria/`: recursos de diagnóstico y acompañamiento tutorial.
- `transversal/`: documentos compartidos entre varias áreas.

Se aceptan archivos `.md` y `.txt`, tanto en esta carpeta como en las subcarpetas. Después de agregar, modificar o quitar archivos, use **Reindexar documentos** en la pestaña Base documental. Los archivos `README.md` de orientación de las carpetas no se incorporan al índice.

También puede arrastrar uno o varios archivos `.md` o `.txt` UTF-8 al cargador de la pestaña **Base documental**, elegir el área y seleccionar **Guardar documentos**. Cada archivo puede pesar hasta 10 MB. La aplicación no sobrescribe nombres existentes en el área seleccionada; revise el mensaje de resultado si un archivo no pudo guardarse. Después de cargar, use los filtros por área y tipo para localizar un documento y consultar su vista previa.

Las respuestas se pueden descargar como archivo Markdown desde la pestaña **Asistente**. La exportación incluye la consulta, el módulo, la respuesta y los fragmentos recuperados con el nombre del archivo y la relevancia. No se conservan páginas ni folios, por lo que las citas identifican el documento y el fragmento, no una página precisa.

No agregue datos personales, expedientes ni documentos confidenciales sin autorización institucional y las medidas de protección correspondientes.
