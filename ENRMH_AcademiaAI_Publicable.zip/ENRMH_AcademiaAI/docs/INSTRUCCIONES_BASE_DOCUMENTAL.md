# Base documental ENRMH

Coloque aquí únicamente documentos institucionales autorizados para consulta del sistema.

## Directorio por área

- `planeacion/`: planeaciones, programas y secuencias.
- `evaluacion/`: instrumentos, rúbricas y orientaciones de evaluación.
- `titulacion/`: materiales autorizados para acompañar procesos de titulación.
- `investigacion/`: protocolos, metodologías y recursos de investigación.
- `tutoria/`: recursos de diagnóstico y acompañamiento tutorial.
- `transversal/`: documentos compartidos entre varias áreas.

Se aceptan archivos `.md` y `.txt`, tanto en esta carpeta como en las subcarpetas. Después de agregar, modificar o quitar archivos, use **Reindexar documentos** en la pestaña Base documental. Los archivos `README.md` de orientación de las carpetas no se incorporan al índice.

No agregue datos personales, expedientes ni documentos confidenciales sin autorización institucional y las medidas de protección correspondientes.
