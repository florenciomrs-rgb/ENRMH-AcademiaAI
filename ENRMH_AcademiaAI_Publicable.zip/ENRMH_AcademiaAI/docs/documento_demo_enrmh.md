ESCUELA NORMAL RURAL “MIGUEL HIDALGO”
Documento demostrativo de conocimiento institucional

PLAN DE ESTUDIOS 2022
La formación inicial docente se organiza mediante cursos, unidades de aprendizaje, evidencias y procesos de acompañamiento. Las actividades deben articularse con el perfil de egreso, los saberes profesionales y los contextos escolares y comunitarios.

ACOMPAÑAMIENTO ACADÉMICO
El acompañamiento debe favorecer diálogo, retroalimentación, seguimiento de evidencias y toma de decisiones informada. La IA puede asistir en la organización y análisis, pero la valoración académica corresponde al personal responsable.

EVALUACIÓN
Los instrumentos pueden incluir rúbricas, listas de cotejo, escalas y retroalimentación descriptiva, siempre alineados con los propósitos y evidencias de aprendizaje.

TITULACIÓN
El acompañamiento de titulación requiere seguimiento de avances, observaciones, acuerdos y evidencias conforme a los documentos institucionales vigentes.
