# Investigación

Agregue aquí documentos institucionales autorizados sobre protocolos, metodología y recursos de investigación en formato `.md` o `.txt`.
