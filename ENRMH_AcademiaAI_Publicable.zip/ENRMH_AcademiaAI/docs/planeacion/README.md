# Planeación 2022

Agregue aquí documentos institucionales autorizados sobre programas, planeaciones y secuencias didácticas en formato `.md` o `.txt`.
