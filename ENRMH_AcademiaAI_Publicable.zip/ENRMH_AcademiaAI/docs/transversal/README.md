# Documentos transversales

Agregue aquí documentos institucionales autorizados de consulta compartida entre áreas en formato `.md` o `.txt`.
